#pragma once

#define CORE_M3 1

/* from lpcopen */
#include "chip.h"
