#pragma once

#ifndef __CONCAT
#define __CONCAT1(x,y) x ## y
#define __CONCAT(x,y) __CONCAT1(x,y)
#endif
