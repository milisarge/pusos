
// pico sdk expects this to include boards/xyz.h and define PICO_*

// we instead define those via GLOBAL defines in target/pico/rules.mk
